<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

class ChooseVirementEvent implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $bank;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($bank)
    {
        $this->bank = $bank;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */

    public function broadcastOn()
    {
        return new Channel('wallet-bank-choose-created');
    }

    public function broadcastWith()
    {

        return [

            'id' =>  $this->bank->id,
            'updated_by' =>  $this->bank->updated_by,
            'userId'  =>   $this->bank->wallet->sidUser->id ?? 12,

        ];
    }

    public function broadcastAs()
    {
        return 'Created_wallet_bank_choose';
    }
}