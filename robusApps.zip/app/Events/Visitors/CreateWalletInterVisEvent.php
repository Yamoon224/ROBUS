<?php

namespace App\Events\Visitors;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;

class CreateWalletInterVisEvent implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $inter;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($inter)
    {
        $this->inter = $inter;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */

    public function broadcastOn()
    {
        return new Channel('wallet-inter-vis-created');
    }

    public function broadcastWith()
    {
        return [
            'id' =>  $this->inter->id,
            'provider'  =>  $this->inter->provider->name,
            'amount' =>  $this->inter->amount,
            'type' =>  'Inter',
            'description'  =>   $this->inter->description,
            'date_created' =>  $this->inter->created_at
        ];
    }

    public function broadcastAs()
    {
        return 'Created_wallet_inter_vis';
    }
}