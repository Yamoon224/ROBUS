<?php

namespace App\Http\Services;


use App\Models\AdminsCom;
use App\Models\Sid\SidUser;
use Illuminate\Support\Facades\DB;
use App\Repositories\VersementRepository;
use App\Http\Services\OperatorRestrictionService;
use App\Http\Services\CommissionService;

class VersementService
{

    /** @var  VersementRepository */
    public $versementRepository;
    protected $operatorRestrictionService;
    protected $commissionServices;

    public function __construct(
        VersementRepository $paiementReposi,
        OperatorRestrictionService $operatorRestrictionService,
        CommissionService $commissionServices

    ) {
        $this->versementRepository = $paiementReposi;
        $this->operatorRestrictionService = $operatorRestrictionService;
        $this->commissionServices = $commissionServices;
    }


    public function createRobusWalletTransactionPayment(
        $reel_amount,
        $valeur_received,
        $amount_valeur,
        $provider,
        $percent_robus,
        $num_accompte,
        $bank_code,
        $guichet_code,
        $num_authers,
        $name
    ) {

        $amount_solde = robus()->wallet->amount - $amount_valeur;

        return $this->versementRepository->create([
            'wallet_id' =>  robus()->wallet->id,
            'amount' => $reel_amount,
            'amount_solde' => $amount_solde ?? null,
            'amount_received' => $valeur_received ?? null,
            'description'  => "Paiement versements",
            'balance_before' =>  robus()->wallet->amount,
            'virement_percent_id' => $percent_robus->id,
            'num_accompte'   => $num_accompte ?? null,
            'bank_code' => $bank_code ?? null,
            'guichet_code' => $guichet_code ?? null,
            'full_name' => $name ?? null,
            'created_by' => robus()->id,
            'provider_id'  =>    $provider,
            'num_authers' => $num_authers ?? null,
            'costs_amount' => ($percent_robus->percent * $amount_valeur),
            'status'  => "PENDING",
        ]);
    }

    public function updateAmountPaymentReceveid($admin_civ, $percent_robus, $walletPayment, $amount)
    {

        $amount_commission =  $amount;

        $amount_solde = robus()->wallet->amount - $amount;
        $userId = robus()->id;
        $activeButtons = $this->operatorRestrictionService->getActiveButtons($userId);
        $account_accepted = robus()->is_accepted_companie ?? false;
        $company_id = robus()->company_id ?? null;
        if ($company_id) {
            $compagnie = SidUser::whereIsCompany(true)->where('company_id', $company_id)->first();
            $sidUserId = $account_accepted && $compagnie ? $compagnie->id : null;
        } else {
            $compagnie = null;
            $sidUserId = null;
        }

        if ($sidUserId) {
            $activeCButtons = $this->operatorRestrictionService->getActiveCButtons($sidUserId);
        } else {
            $activeCButtons = [];
        }

        robus()->wallet->update([
            'reload_by' => robus()->firstname . ' ' . robus()->lastname,
            'sid_user_relod' => robus()->id,
            'amount' => DB::raw('amount-'  .  $amount_commission),
        ]);

        $walletPayment->update([
            'amount_solde' => $amount_solde,
        ]);

        $amount_bank =  $percent_robus->percent_bank_custumer * $walletPayment->amount;

        if (robus()->is_under_distributer || robus()->is_api) {

            $valuer_deposit =  $percent_robus->percent_merchands * $walletPayment->amount;
            $admin_nocomission =  $percent_robus->percent * $walletPayment->amount;

            if (!empty($activeButtons['showRemonterVersementButton'])) {

                $walletPayment->update([
                    'commissions' => $valuer_deposit,
                ]);

                $admin_valeur =  $percent_robus->percent_admin  * $walletPayment->amount;
                $admin_no_compagie =  $percent_robus->percent_companie  * $walletPayment->amount;

                $cumul_amount =  (float) $admin_valeur + (float) $admin_no_compagie;

                $account_accepted = robus()->is_accepted_companie ?? false;

                if ($account_accepted && !empty($activeCButtons['showRemonterVersementCButton'])) {

                    $valuer_companie = $percent_robus->percent_companie * $walletPayment->amount;

                    $walletPayment->increment('commission_companie', $valuer_companie);

                    $this->commissionServices->distributeAdminAndVersementCommissionAcceptedCompanies($admin_civ, 'wallet_versement_id', $walletPayment->id, $admin_valeur, $valuer_companie, $valuer_deposit, $amount_bank);
                } else {
                    $this->commissionServices->distributeAdminAndBankCommissionAccepteds($admin_civ, 'wallet_versement_id', $walletPayment->id, $cumul_amount, $valuer_deposit, $amount_bank);
                }
            } else {

                $this->commissionServices->distributeAdminAndBankCommissions($admin_civ, 'wallet_versement_id', $walletPayment->id, $admin_nocomission,  $amount_bank);
            }
        } else {

            $admin_percent_valeur =  $percent_robus->percent_admin_custumer * $walletPayment->amount;;
            $this->commissionServices->distributeAdminAndBankCommissions($admin_civ, 'wallet_versement_id', $walletPayment->id, $admin_percent_valeur,  $amount_bank);
        }

        return true;
    }
}
